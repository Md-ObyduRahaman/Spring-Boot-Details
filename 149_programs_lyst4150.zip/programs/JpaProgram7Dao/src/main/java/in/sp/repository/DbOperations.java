package in.sp.repository;

import in.sp.entity.Student;

public interface DbOperations 
{
	public boolean insertStdDetails(Student std);
}