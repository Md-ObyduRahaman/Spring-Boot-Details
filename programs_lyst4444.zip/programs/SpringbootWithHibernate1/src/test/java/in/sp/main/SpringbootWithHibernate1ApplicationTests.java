package in.sp.main;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootWithHibernate1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
