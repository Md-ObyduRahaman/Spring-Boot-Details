package in.sp.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoggingDemo2LogbackApplication
{
	public static void main(String[] args)
	{
		SpringApplication.run(LoggingDemo2LogbackApplication.class, args);
	}
}