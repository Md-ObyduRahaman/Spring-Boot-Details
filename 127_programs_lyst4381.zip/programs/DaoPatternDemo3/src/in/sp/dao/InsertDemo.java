package in.sp.dao;

public interface InsertDemo 
{
	public boolean insertValues();
}